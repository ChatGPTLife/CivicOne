import os
import logging
from dotenv import load_dotenv

from telegram import (
    Update,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardMarkup,
    ReplyKeyboardRemove,
)
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    ContextTypes,
    filters,
)

load_dotenv()

BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")

if not BOT_TOKEN:
    raise RuntimeError(
        "TELEGRAM_BOT_TOKEN is missing. Put your bot token in the .env file."
    )

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)


# ---------- MENUS ----------

def main_menu():
    keyboard = [
        [InlineKeyboardButton("🚨 Emergency", callback_data="emergency")],
        [InlineKeyboardButton("📍 Nearby Services", callback_data="nearby")],
        [InlineKeyboardButton("📢 Report an Issue", callback_data="report")],
        [InlineKeyboardButton("ℹ️ Help", callback_data="help")],
    ]
    return InlineKeyboardMarkup(keyboard)


def emergency_menu():
    keyboard = [
        [InlineKeyboardButton("👮 Police", callback_data="police")],
        [InlineKeyboardButton("🚑 Ambulance", callback_data="ambulance")],
        [InlineKeyboardButton("🔥 Fire & Rescue", callback_data="fire")],
        [InlineKeyboardButton("↩️ Back", callback_data="main")],
    ]
    return InlineKeyboardMarkup(keyboard)


def nearby_menu():
    keyboard = [
        [InlineKeyboardButton("🏥 Hospitals", callback_data="nearby_hospital")],
        [InlineKeyboardButton("👮 Police Stations", callback_data="nearby_police")],
        [InlineKeyboardButton("🔥 Fire Stations", callback_data="nearby_fire")],
        [InlineKeyboardButton("📍 Share My Location", callback_data="share_location")],
        [InlineKeyboardButton("↩️ Back", callback_data="main")],
    ]
    return InlineKeyboardMarkup(keyboard)


def back_menu():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("↩️ Back to Main Menu", callback_data="main")]
    ])


# ---------- COMMANDS ----------

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user

    text = (
        f"👋 Welcome to *CivicOne*, {user.first_name}!\n\n"
        "Your civic assistance bot.\n\n"
        "Choose an option below:"
    )

    await update.message.reply_text(
        text,
        parse_mode="Markdown",
        reply_markup=main_menu(),
    )


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        "ℹ️ *CivicOne Help*\n\n"
        "Use the buttons to navigate CivicOne.\n\n"
        "Available commands:\n"
        "• /start — Open CivicOne\n"
        "• /menu — Open the main menu\n"
        "• /help — Show this help\n"
        "• /cancel — Cancel the current action"
    )

    await update.message.reply_text(
        text,
        parse_mode="Markdown",
        reply_markup=main_menu(),
    )


async def menu_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🏠 *CivicOne Main Menu*\n\nChoose an option:",
        parse_mode="Markdown",
        reply_markup=main_menu(),
    )


async def cancel_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.clear()

    await update.message.reply_text(
        "❌ Current action cancelled.\n\nChoose an option:",
        reply_markup=main_menu(),
    )


# ---------- BUTTON HANDLER ----------

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query

    # Very important: acknowledge the callback.
    await query.answer()

    data = query.data

    if data == "main":
        await query.edit_message_text(
            "🏠 *CivicOne Main Menu*\n\nChoose an option:",
            parse_mode="Markdown",
            reply_markup=main_menu(),
        )

    elif data == "emergency":
        await query.edit_message_text(
            "🚨 *Emergency Services*\n\n"
            "Choose the service you need:",
            parse_mode="Markdown",
            reply_markup=emergency_menu(),
        )

    elif data == "police":
        await query.edit_message_text(
            "👮 *Police Emergency*\n\n"
            "For immediate police assistance, call *112* in India.\n\n"
            "If this is an emergency, contact emergency services immediately.",
            parse_mode="Markdown",
            reply_markup=back_menu(),
        )

    elif data == "ambulance":
        await query.edit_message_text(
            "🚑 *Ambulance Emergency*\n\n"
            "For immediate medical emergency assistance, call *112* in India.\n\n"
            "If someone is seriously injured or ill, seek emergency medical help immediately.",
            parse_mode="Markdown",
            reply_markup=back_menu(),
        )

    elif data == "fire":
        await query.edit_message_text(
            "🔥 *Fire & Rescue*\n\n"
            "For a fire or immediate danger, call *112* in India.\n\n"
            "Move to a safe location and follow instructions from emergency responders.",
            parse_mode="Markdown",
            reply_markup=back_menu(),
        )

    elif data == "nearby":
        await query.edit_message_text(
            "📍 *Nearby Services*\n\n"
            "Choose a service or share your location:",
            parse_mode="Markdown",
            reply_markup=nearby_menu(),
        )

    elif data == "nearby_hospital":
        await query.edit_message_text(
            "🏥 *Nearby Hospitals*\n\n"
            "Location-based hospital search will be connected here.",
            parse_mode="Markdown",
            reply_markup=back_menu(),
        )

    elif data == "nearby_police":
        await query.edit_message_text(
            "👮 *Nearby Police Stations*\n\n"
            "Location-based police station search will be connected here.",
            parse_mode="Markdown",
            reply_markup=back_menu(),
        )

    elif data == "nearby_fire":
        await query.edit_message_text(
            "🔥 *Nearby Fire Stations*\n\n"
            "Location-based fire station search will be connected here.",
            parse_mode="Markdown",
            reply_markup=back_menu(),
        )

    elif data == "share_location":
        # Telegram cannot request a location from an inline button.
        # We switch to a temporary reply keyboard containing a location button.
        location_keyboard = ReplyKeyboardMarkup(
            [[KeyboardButton("📍 Share My Location", request_location=True)]],
            resize_keyboard=True,
            one_time_keyboard=True,
        )

        await query.message.reply_text(
            "📍 Please tap *Share My Location* below.\n\n"
            "Your location will only be used for the nearby-services feature.",
            parse_mode="Markdown",
            reply_markup=location_keyboard,
        )

    elif data == "report":
        context.user_data["state"] = "report"

        await query.edit_message_text(
            "📢 *Report an Issue*\n\n"
            "Please send a short description of the issue.\n\n"
            "Example:\n"
            "_\"Large pothole near the main entrance of VIT Chennai.\"_\n\n"
            "Use /cancel to cancel.",
            parse_mode="Markdown",
        )

    elif data == "help":
        await query.edit_message_text(
            "ℹ️ *CivicOne Help*\n\n"
            "Use the buttons to access emergency services, "
            "nearby civic services, and issue reporting.\n\n"
            "Commands:\n"
            "• /start\n"
            "• /menu\n"
            "• /help\n"
            "• /cancel",
            parse_mode="Markdown",
            reply_markup=back_menu(),
        )


# ---------- LOCATION ----------

async def location_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    location = update.message.location

    latitude = location.latitude
    longitude = location.longitude

    # For now, just confirm the coordinates.
    # Later this is where we can call Google Maps / OpenStreetMap / another API.
    await update.message.reply_text(
        f"📍 Location received!\n\n"
        f"Latitude: `{latitude}`\n"
        f"Longitude: `{longitude}`\n\n"
        "Nearby-service API integration can be added here.",
        parse_mode="Markdown",
        reply_markup=ReplyKeyboardRemove(),
    )

    await update.message.reply_text(
        "What would you like to do next?",
        reply_markup=main_menu(),
    )


# ---------- TEXT / REPORT HANDLER ----------

async def text_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    state = context.user_data.get("state")

    if state == "report":
        report_text = update.message.text

        # For now, store it only in the user's current session.
        # A database can be added later.
        context.user_data["report"] = report_text
        context.user_data["state"] = None

        await update.message.reply_text(
            "✅ *Report received!*\n\n"
            f"Your report:\n_{report_text}_\n\n"
            "A database/backend can be connected here to permanently "
            "store and process reports.",
            parse_mode="Markdown",
            reply_markup=main_menu(),
        )
    else:
        await update.message.reply_text(
            "I didn't understand that. Please use the menu below.",
            reply_markup=main_menu(),
        )


# ---------- ERROR HANDLER ----------

async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    logger.error("Exception while handling update:", exc_info=context.error)


# ---------- MAIN ----------

def main():
    application = Application.builder().token(BOT_TOKEN).build()

    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("menu", menu_command))
    application.add_handler(CommandHandler("cancel", cancel_command))

    application.add_handler(CallbackQueryHandler(button_handler))

    application.add_handler(
        MessageHandler(filters.LOCATION, location_handler)
    )

    application.add_handler(
        MessageHandler(filters.TEXT & ~filters.COMMAND, text_handler)
    )

    application.add_error_handler(error_handler)

    print("CivicOne Telegram bot is running...")
    print("Press Ctrl+C to stop.")

    application.run_polling()


if __name__ == "__main__":
    main()
